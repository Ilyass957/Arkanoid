using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI; // We have to add the UnityEngine.UI namespace in order to work with Text variables

public class Ball : MonoBehaviour
{
    float hitFactor(Vector2 ballPos, Vector2 racketPos,
                float racketHeight) {
    // ascii art:
    // 
    // 1  -0.5  0  0.5  1 <- x value
    // ================== <- racket
    return (ballPos.x - racketPos.x) / racketHeight;
          }

    public float speed = 30f;
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI scoreText2;
    int score;
    // Start is called before the first frame update
    void Start()
    {
        GetComponent<Rigidbody2D>().velocity = -Vector2.up * speed;
    }

    // Update is called once per frame
    void Update()22
    {
        
    }
    void OnCollisionEnter2D(Collision2D col)
    {
        // Hit the left Racket?
        if (col.gameObject.name == "racket") 
	    {
            // Calculate hit Factor
            float x = hitFactor(transform.position,
                            col.transform.position,
                            col.collider.bounds.size.x);
        // Calculate direction, make length=1 via .normalized
        Vector2 dir = new Vector2(x,1).normalized;    
          // Set Velocity with dir * speed
        GetComponent<Rigidbody2D>().velocity = dir * speed;
        }  
        //this is our condition (if the ball collides with a block_blue (1))
        if (col.gameObject.tag == "block") {
            //this line will just add 1 point to the score
            score ++;
            //this line will convert the int score variable to a string variable
            scoreText.text = score.ToString ();
        } 
    }     
}
